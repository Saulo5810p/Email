/*
 * Copyright (C) 2014 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.android.email;

import android.content.Context;

public class NotificationControllerCreatorHolder {
    private static NotificationControllerCreator sCreator =
            new NotificationControllerCreator() {
                @Override
                public NotificationController getInstance(Context context){
                    return null;
                }
            };

    public static void setNotificationControllerCreator(
            NotificationControllerCreator creator) {
        sCreator = creator;
    }

    public static NotificationControllerCreator getNotificationControllerCreator() {
        return sCreator;
    }

    public static NotificationController getInstance(Context context) {
        return getNotificationControllerCreator().getInstance(context);
    }
}